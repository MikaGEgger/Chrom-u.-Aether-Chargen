using System.Windows;

namespace WpfApp
{
    public static class CharacterGenerator
    {
        public static void GenerateRandomCharacter(int val1, int val2, int val3, int val4, string name)
        {
            MessageBox.Show($"Generating Random Character for {name} with values: {val1}, {val2}, {val3}, {val4}", 
                "Random Character");
        }
    }
}