namespace chargen.Character.CharacterProperties
{
    public enum ProficiencyLevel
    {
        None,
        Trained,
        Proficient,
        Expert
    }
}